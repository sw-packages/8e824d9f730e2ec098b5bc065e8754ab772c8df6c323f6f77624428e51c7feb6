#include "compiler.h"
#include <stdio.h>

FILE *error_file;

